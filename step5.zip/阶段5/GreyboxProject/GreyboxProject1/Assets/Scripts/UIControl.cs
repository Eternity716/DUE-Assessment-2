using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIControl : MonoBehaviour
{
    public GameObject Menu;
    public GameObject MainUI;
    public GameObject ControlUI;
    // Start is called before the first frame update
    void Start()
    {
        MainUI.SetActive(true);
        Menu.SetActive(false);
        ControlUI.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void OnClickMenu()
    {
        MainUI.SetActive(true);
        Menu.SetActive(false);
        ControlUI.SetActive(false);
    }

    public void OnClickStart()
    {
        MainUI.SetActive(false);
        Menu.SetActive(true);
        ControlUI.SetActive(true);
    }
}
